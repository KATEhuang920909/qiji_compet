# ChineseAddressNER
阿里中文地址要素的命名体提取，包含torch，tf, paddle 版本，采用了bert+gru+crf和bert+crf方式，bert+gru+crf f1_score比单纯的bert+crf提高了1到2个百分点
