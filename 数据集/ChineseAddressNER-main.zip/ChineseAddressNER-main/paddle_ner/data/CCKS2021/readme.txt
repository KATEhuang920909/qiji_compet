中文地址要素解析标注规范.pdf	 数据标注规范
train.conll      训练数据
dev.conll	验证数据（建议验证集）
final_test.txt	测试数据 

