from src.recongnizer import Recongnizer
from src.utils.config import config

if __name__ == '__main__':
    recongnizer = Recongnizer(config)
    # recongnizer.fit()
